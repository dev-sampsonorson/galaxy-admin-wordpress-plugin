<?php
/**
 * Galaxy Admin Plugin functions and definitions
 *
 *
 * @package Galaxy
 */
