<?php
/* if (!session_id())
    session_start(); */

/**
 * @package Galaxy Admin Plugin
 */

use Rakit\Validation\Validator;

class ApplicationFormController extends BaseController
{
    public $settings;

    private $post_id;
    private $validator;
    private ExamRepository $examRepository;
    private StudentValidator $studentValidator;
    private GuardianValidator $guardianValidator;
    private PurchaseHeaderValidator $purchaseHeaderValidator;
    private PurchaseItemValidator $purchaseItemValidator;

    private const EXAM_REGISTRATION = 'exam-registration';
    private const BOOK_PURCHASE = 'book-purchase';
    private const LESSON_ENROLMENT = 'lesson-enrolment';

    public function register()
    {
        $post = get_page_by_title('Application Form');
        $this->post_id = isset($post)? $post->ID : 0;

        $this->validator = new Validator();
        $this->studentValidator = StudentValidator::getInstance();
        $this->guardianValidator = GuardianValidator::getInstance();
        $this->purchaseHeaderValidator = PurchaseHeaderValidator::getInstance();
        $this->purchaseItemValidator = PurchaseItemValidator::getInstance();

        $this->settings = new SettingsApi();
        $this->callbacks = new ApplicationFormCallbacks($this);

        $this->examRepository = new ExamRepository();
        $this->guardianRepository = new GuardianRepository();
        $this->purchaseHeaderRepository = new PurchaseHeaderRepository();
        $this->purchaseItemRepository = new PurchaseItemRepository();
        $this->studentRepository = new StudentRepository();

        add_shortcode('galaxy-application-form', array($this->callbacks, 'renderApplicationForm'));

        if ( is_admin() ) {
            add_action('wp_ajax_getExamList', array($this, 'getExamList'));
            add_action('wp_ajax_nopriv_getExamList', array($this, 'getExamList'));
            
            add_action('wp_ajax_saveApplication', array($this, 'saveApplication'));
            add_action('wp_ajax_nopriv_saveApplication', array($this, 'saveApplication'));
        } else {
            // Add non-Ajax front-end action hooks here
        }
    }

    public function getExamList() {
        try {
            if (!DOING_AJAX || !check_ajax_referer('getExamList_nonce', 'nonce', false)) {
                return $this->return_json_error(500, 'Invalid request');
            }

            $result = BaseController::toEntityArray($this->examRepository->getAll());
            
            return $this->return_json(200, $result);
        } catch(Exception $e) {
            return return_json_error(404, 'Exams Not Found');
        }
    }

    public function saveApplication() {
        try {
            if (!DOING_AJAX || !check_ajax_referer('saveApplication_nonce', 'nonce', false)) {
                return $this->return_json_error(500, 'Invalid request');
            }
            
            $applicationData = json_decode(stripslashes($_POST['data']));

            // Save personal data
            $studentEntity = $this->getStudentEntity($applicationData[1]);
            $studentResult = $this->saveStudentData($studentEntity);

            if (!$studentResult->getStatus())
                return $this->return_json_error(400, $studentResult->getMessage(), $studentResult->toArray());

            $studentId = $studentResult->getSuccessResult()->getId();

            // Save guardian data
            $guardianEntity = $this->getGuardianEntity($studentId, $applicationData[2]);
            $guardianResult = $this->saveGuardianData($studentId, $guardianEntity);

            if (!$guardianResult->getStatus())
                return $this->return_json_error(400, $guardianResult->getMessage(), $guardianResult->toArray());

            // Save purchase data
            $purchaseEntity = $this->getPurchaseEntity($studentId, $applicationData[0]);
            $purchaseHeaderResult = $this->savePurchaseData($studentId, $purchaseEntity);

            if (!$purchaseHeaderResult->getStatus())
                return $this->return_json_error(400, $purchaseHeaderResult->getMessage(), $purchaseHeaderResult->toArray());
            
            return $this->return_json(200, array(
                $purchaseHeaderResult->getResult()->toArray(), 
                $studentResult->getResult()->toArray(),
                $guardianResult->getResult()->toArray()
            ));
        } catch(Exception $e) {
            // echo 'Message: ' .$e->getMessage();
            /* $errorMsg = 'Error on line '.$this->getLine().' in '.$this->getFile()
    .': <b>'.$this->getMessage().'</b> is not a valid E-Mail address'; */
            return $this->return_json_error(400, 'Unable to save application');
        }
    }

    private function getPurchaseEntity(int $studentId, object $data): PurchaseHeader {
        $entity = new PurchaseHeader(array(
            "studentId" => $studentId,
            "emailAddress" => $data->emailAddress,
            "total" => floatval($data->total)
        ));

        foreach($data->purchases as $key => $value) {
            $examEntity = $this->examRepository->getById($value->examId);
            $examEntityAsArray = $examEntity->toArray();

            $item = new PurchaseItem(array(
                "examId" => $value->examId,
                "examRegistration" => in_array(self::EXAM_REGISTRATION, $value->selectedServices, true),
                "bookPurchase" => in_array(self::BOOK_PURCHASE, $value->selectedServices, true),
                "lessonEnrolment" => in_array(self::LESSON_ENROLMENT, $value->selectedServices, true),
                "preferredExamDate" => Helper::toDateTimeFromString($value->preferredExamDate),
                "alternativeExamDate" => Helper::toDateTimeFromString($value->alternativeExamDate),
                "preferredExamLocation" => $value->preferredExamLocation,
                "alternativeExamLocation" => $value->alternativeExamLocation,
                "examRegistrationPrice" => $examEntityAsArray["examRegistrationPrice"],
                "bookPurchasePrice" => $examEntityAsArray["bookPurchasePrice"],
                "lessonEnrolmentPrice" => $examEntityAsArray["lessonEnrolmentPrice"],
                "itemTotal" => floatval($value->itemTotal),
            ));

            $entity->addItem($item);
        }

        return $entity;
    }

    private function getStudentEntity(object $data): Student {
        return new Student(array(
            "title" => $data->title,
            "lastName" => $data->lastName,
            "firstName" => $data->firstName,
            "otherNames" => $data->otherName,
            "gender" => $data->gender,
            "birthDate" => Helper::toDateTimeFromString($data->birthDate, WB_DATE_FORMAT),
            "firstLanguage" => $data->firstLanguage,
            "country" => $data->country,
            "state" => $data->state,
            "phoneNumber" => $data->phoneNumber,
            "passportNumber" => $data->passportNumber,
            "expiryDate" => Helper::toDateTimeFromString($data->passportExpiryDate, WB_DATE_FORMAT),
            "permanentAddress" => $data->permanentAddress,
            "currentLevelOfStudy" => $data->currentLevelOfStudy,
            "nextLevelOfStudy" => $data->nextLevelOfStudy
        ));
    }

    private function getGuardianEntity(int $studentId, object $data): Guardian {
        return new Guardian(array(
            "studentId" => $studentId,
            "lastName" => $data->lastName,
            "firstName" => $data->firstName,
            "country" => $data->country,
            "state" => $data->state,
            "educationalBackground" => $data->educationalBackground,
            "occupation" => $data->occupation,
            "currentPosition" => $data->currentPosition,
            "officeAddress" => $data->officeAddress,
            "emailAddress" => $data->emailAddress,
            "phoneNumber" => $data->phoneNumber
        ));        
    }

    private function saveStudentData(Student $entity): Result { //Student
        $result = $this->studentValidator->validate($entity);
        
        if (count($result) > 0)
            return Result::fromErrorWithResult(AppError::ERROR_VALIDATION, $result, "Invalid personal information");

        $student = $this->studentRepository->insert($entity);        
        
        if ($student == null)
            return Result::fromError(AppError::ERROR_GENERAL, "Unable to save student information");

        return Result::fromSuccess($student);
    }

    private function savePurchaseData(int $studentId, PurchaseHeader $entity): Result { //PurchaseHeader
        $result = $this->purchaseHeaderValidator->validate($entity);
        
        if (count($result) > 0)
            return Result::fromErrorWithResult(AppError::ERROR_VALIDATION, $result, "Invalid purchase information");

        $purchaseHeader = $this->purchaseHeaderRepository->insert($entity);
        
        if ($purchaseHeader == null)
            return Result::fromError(AppError::ERROR_GENERAL, "Unable to save purchase information");

        $purchaseItems = $purchaseHeader->getItems();

        foreach($purchaseItems as $item) {
            $item->setPurchaseId($purchaseHeader->getId());

            $purchaseItemValResult = $this->purchaseItemValidator->validate($item);

            if (count($purchaseItemValResult) > 0)
                return Result::fromErrorWithResult(AppError::ERROR_VALIDATION, $purchaseItemValResult, "Invalid purchase item information");
            
            $purchaseItem = $this->purchaseItemRepository->insert($item);
        
            if ($purchaseItem == null)
                return Result::fromError(AppError::ERROR_GENERAL, "Unable to save purchase item information");
        }

        return Result::fromSuccess($purchaseHeader);
    }

    private function saveGuardianData(int $studentId, Guardian $entity): Result { // Guardian
        $result = $this->guardianValidator->validate($entity);
        
        if (count($result) > 0)
            return Result::fromErrorWithResult(AppError::ERROR_VALIDATION, $result, "Invalid guardian information");

        $guardian = $this->guardianRepository->insert($entity);  
        
        if ($guardian == null)
            return Result::fromError(AppError::ERROR_GENERAL, "Unable to save guardian information");

        return Result::fromSuccess($guardian);      
    }
}