<div class="wrap">

    <h1>Galaxy Admin Shortcode</h1> 

    <p>Application Form Shortcode</p>
    <p><code>[galaxy-application-form]</code></p>

</div>