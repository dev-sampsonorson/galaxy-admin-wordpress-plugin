<?php

    use Rakit\Validation\Rule;

    class PurchaseItemRule extends Rule {

        protected $message = "One or more purchase items are not valid";
        protected $fillableParams = ['items'];

        public function __constructor() {

        }

        public function check($value): bool {
            try {
                // make sure required parameters exists
                // $this->requireParameters(['items']);
    
                // getting parameters
                $items = $this->parameter('items');
    
                foreach($entityList as $value) {
                    $result = self::$purchaseItemValidator->validate($value);
    
                    if (count($result) > 0) 
                        return false;
                }
    
                return true;
            } catch (Exception $e) {
                echo $e->getMessage();
                return false;
            }
        }

    }