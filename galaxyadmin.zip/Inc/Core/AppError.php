<?php

    /**
     * @package Galaxy Admin Plugin
     */

    class AppError {
        
        public const ERROR_VALIDATION = 'error-validation';
        public const ERROR_GENERAL = 'error-general';
        
    }